import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  Switch, 
  TouchableOpacity, 
  Alert,
  Modal,
  TextInput
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function TelaConfiguracoes() {
  const [temaEscuro, setTemaEscuro] = useState(false);
  const [idioma, setIdioma] = useState('Português');
  const [notificacoesAtivadas, setNotificacoesAtivadas] = useState(true);
  const [backupDialogVisible, setBackupDialogVisible] = useState(false);
  const [excluirDialogVisible, setExcluirDialogVisible] = useState(false);
  const [emailBackup, setEmailBackup] = useState('');

  const alternarTema = () => setTemaEscuro(!temaEscuro);
  const alternarNotificacoes = () => setNotificacoesAtivadas(!notificacoesAtivadas);

  const selecionarIdioma = (novoIdioma) => {
    setIdioma(novoIdioma);
    Alert.alert('Idioma alterado', `O idioma foi definido para ${novoIdioma}`);
  };

  const fazerBackup = () => {
    if (emailBackup) {
      Alert.alert('Backup realizado', `Um backup dos seus dados foi enviado para ${emailBackup}`);
      setBackupDialogVisible(false);
      setEmailBackup('');
    } else {
      Alert.alert('E-mail necessário', 'Por favor, informe um e-mail válido');
    }
  };

  const confirmarExclusaoConta = () => {
    Alert.alert(
      'Confirmação',
      'Tem certeza que deseja excluir sua conta permanentemente? Esta ação não pode ser desfeita.',
      [
        { text: 'Cancelar', style: 'cancel' },
        { 
          text: 'Excluir', 
          style: 'destructive',
          onPress: () => {
            setExcluirDialogVisible(false);
            
            Alert.alert('Conta excluída', 'Sua conta foi excluída com sucesso');
          }
        }
      ]
    );
  };

  const abrirHistorico = () => {
    
    Alert.alert('Histórico de tarefas', 'Aqui você veria todas as tarefas concluídas');
  };

  
  const containerStyle = temaEscuro ? styles.containerEscuro : styles.containerClaro;
  const textStyle = temaEscuro ? styles.textoEscuro : styles.textoClaro;
  const cardStyle = temaEscuro ? styles.cardEscuro : styles.cardClaro;

  return (
    <ScrollView style={containerStyle}>
      <Text style={[styles.titulo, textStyle]}>Configurações</Text>

      
      <View style={[styles.card, cardStyle]}>
        <Text style={[styles.subtitulo, textStyle]}>Aparência</Text>
        
        <View style={styles.itemConfiguracao}>
          <Ionicons name="moon" size={24} color={temaEscuro ? "#bb86fc" : "#6200ee"} />
          <Text style={[styles.textoItem, textStyle]}>Tema escuro</Text>
          <Switch
            value={temaEscuro}
            onValueChange={alternarTema}
            trackColor={{ false: '#767577', true: '#81b0ff' }}
            thumbColor={temaEscuro ? '#f5dd4b' : '#f4f3f4'}
          />
        </View>
        
        <View style={styles.itemConfiguracao}>
          <Ionicons name="language" size={24} color={temaEscuro ? "#bb86fc" : "#6200ee"} />
          <Text style={[styles.textoItem, textStyle]}>Idioma</Text>
          <TouchableOpacity 
            style={styles.botaoSelecao}
            onPress={() => Alert.alert(
              'Selecionar idioma',
              'Escolha o idioma do aplicativo:',
              [
                { text: 'Português', onPress: () => selecionarIdioma('Português') },
                { text: 'Inglês', onPress: () => selecionarIdioma('Inglês') },
                { text: 'Espanhol', onPress: () => selecionarIdioma('Espanhol') },
                { text: 'Cancelar', style: 'cancel' },
              ]
            )}
          >
            <Text style={styles.textoBotaoSelecao}>{idioma}</Text>
            <Ionicons name="chevron-down" size={16} color={temaEscuro ? "#fff" : "#000"} />
          </TouchableOpacity>
        </View>
      </View>

      
      <View style={[styles.card, cardStyle]}>
        <Text style={[styles.subtitulo, textStyle]}>Notificações</Text>
        
        <View style={styles.itemConfiguracao}>
          <Ionicons name="notifications" size={24} color={temaEscuro ? "#bb86fc" : "#6200ee"} />
          <Text style={[styles.textoItem, textStyle]}>Ativar notificações</Text>
          <Switch
            value={notificacoesAtivadas}
            onValueChange={alternarNotificacoes}
            trackColor={{ false: '#767577', true: '#81b0ff' }}
            thumbColor={notificacoesAtivadas ? '#f5dd4b' : '#f4f3f4'}
          />
        </View>
      </View>

      
      <View style={[styles.card, cardStyle]}>
        <Text style={[styles.subtitulo, textStyle]}>Dados</Text>
        
        <TouchableOpacity 
          style={styles.itemConfiguracao}
          onPress={abrirHistorico}
        >
          <Ionicons name="time" size={24} color={temaEscuro ? "#bb86fc" : "#6200ee"} />
          <Text style={[styles.textoItem, textStyle]}>Histórico de tarefas</Text>
          <Ionicons name="chevron-forward" size={20} color={temaEscuro ? "#aaa" : "#666"} />
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.itemConfiguracao}
          onPress={() => setBackupDialogVisible(true)}
        >
          <Ionicons name="cloud-upload" size={24} color={temaEscuro ? "#bb86fc" : "#6200ee"} />
          <Text style={[styles.textoItem, textStyle]}>Backup de dados</Text>
          <Ionicons name="chevron-forward" size={20} color={temaEscuro ? "#aaa" : "#666"} />
        </TouchableOpacity>
      </View>

      
      <View style={[styles.card, cardStyle]}>
        <Text style={[styles.subtitulo, textStyle]}>Conta</Text>
        
        <TouchableOpacity 
          style={[styles.itemConfiguracao, styles.itemPerigoso]}
          onPress={() => setExcluirDialogVisible(true)}
        >
          <Ionicons name="trash" size={24} color="#f44336" />
          <Text style={[styles.textoItem, styles.textoPerigoso]}>Excluir conta</Text>
        </TouchableOpacity>
      </View>

      <Modal
        animationType="slide"
        transparent={true}
        visible={backupDialogVisible}
        onRequestClose={() => setBackupDialogVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={[styles.modalContent, cardStyle]}>
            <Text style={[styles.modalTitulo, textStyle]}>Fazer Backup</Text>
            
            <Text style={[styles.modalTexto, textStyle]}>
              Informe seu e-mail para receber o backup dos seus dados:
            </Text>
            
            <TextInput
              style={[styles.input, textStyle, temaEscuro ? styles.inputEscuro : styles.inputClaro]}
              placeholder="seu@email.com"
              placeholderTextColor={temaEscuro ? "#aaa" : "#888"}
              value={emailBackup}
              onChangeText={setEmailBackup}
              keyboardType="email-address"
              autoCapitalize="none"
            />
            
            <View style={styles.botoesModal}>
              <TouchableOpacity 
                style={styles.botaoModalCancelar}
                onPress={() => setBackupDialogVisible(false)}
              >
                <Text style={styles.textoBotaoModal}>Cancelar</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.botaoModalConfirmar}
                onPress={fazerBackup}
              >
                <Text style={styles.textoBotaoModal}>Enviar Backup</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      
      <Modal
        animationType="slide"
        transparent={true}
        visible={excluirDialogVisible}
        onRequestClose={() => setExcluirDialogVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={[styles.modalContent, cardStyle]}>
            <Ionicons name="warning" size={48} color="#f44336" style={styles.iconeAlerta} />
            <Text style={[styles.modalTitulo, textStyle]}>Excluir Conta</Text>
            
            <Text style={[styles.modalTexto, textStyle]}>
              Tem certeza que deseja excluir sua conta permanentemente? 
              Todos os seus dados serão apagados e esta ação não pode ser desfeita.
            </Text>
            
            <View style={styles.botoesModal}>
              <TouchableOpacity 
                style={styles.botaoModalCancelar}
                onPress={() => setExcluirDialogVisible(false)}
              >
                <Text style={styles.textoBotaoModal}>Cancelar</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.botaoModalPerigoso}
                onPress={confirmarExclusaoConta}
              >
                <Text style={styles.textoBotaoModal}>Excluir Conta</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  
  containerClaro: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  containerEscuro: {
    flex: 1,
    padding: 16,
    backgroundColor: '#121212',
  },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 24,
    marginTop: 16,
  },
  subtitulo: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  textoClaro: {
    color: '#000',
  },
  textoEscuro: {
    color: '#fff',
  },
  card: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cardClaro: {
    backgroundColor: '#fff',
  },
  cardEscuro: {
    backgroundColor: '#1e1e1e',
  },
  itemConfiguracao: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  itemPerigoso: {
    borderBottomColor: 'transparent',
  },
  textoItem: {
    flex: 1,
    fontSize: 16,
    marginLeft: 16,
  },
  textoPerigoso: {
    color: '#f44336',
  },
  botaoSelecao: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#f0f0f0',
  },
  textoBotaoSelecao: {
    marginRight: 8,
    color: '#333',
  },
  
  // Modal
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    width: '85%',
    borderRadius: 12,
    padding: 24,
  },
  modalTitulo: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
  modalTexto: {
    fontSize: 16,
    marginBottom: 20,
    textAlign: 'center',
    lineHeight: 24,
  },
  iconeAlerta: {
    alignSelf: 'center',
    marginBottom: 16,
  },
  input: {
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    marginBottom: 20,
    fontSize: 16,
  },
  inputClaro: {
    borderColor: '#ddd',
    backgroundColor: '#fff',
  },
  inputEscuro: {
    borderColor: '#333',
    backgroundColor: '#2a2a2a',
  },
  botoesModal: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  botaoModalCancelar: {
    flex: 1,
    backgroundColor: '#e0e0e0',
    padding: 14,
    borderRadius: 8,
    alignItems: 'center',
    marginRight: 8,
  },
  botaoModalConfirmar: {
    flex: 1,
    backgroundColor: '#6200ee',
    padding: 14,
    borderRadius: 8,
    alignItems: 'center',
    marginLeft: 8,
  },
  botaoModalPerigoso: {
    flex: 1,
    backgroundColor: '#f44336',
    padding: 14,
    borderRadius: 8,
    alignItems: 'center',
    marginLeft: 8,
  },
  textoBotaoModal: {
    color: '#fff',
    fontWeight: 'bold',
  },
});