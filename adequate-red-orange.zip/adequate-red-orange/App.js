import React from 'react';
import Settings from './screens/settings';

export default function App() {
  return <Settings />;
}
