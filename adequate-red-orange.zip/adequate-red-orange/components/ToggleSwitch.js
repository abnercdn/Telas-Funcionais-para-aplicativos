import React from 'react';
import { Switch } from 'react-native';

export default function ToggleSwitch({ value, onValueChange }) {
  return (
    <Switch
      value={value}
      onValueChange={onValueChange}
      trackColor={{ false: '#ccc', true: '#0f62fe' }}
      thumbColor={value ? '#ffffff' : '#f4f3f4'}
    />
  );
}
